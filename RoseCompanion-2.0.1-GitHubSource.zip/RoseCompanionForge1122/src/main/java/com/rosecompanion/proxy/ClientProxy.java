package com.rosecompanion.proxy;

import com.rosecompanion.client.RenderRoseDog;
import com.rosecompanion.client.RoseClientEvents;
import com.rosecompanion.entity.EntityRoseDog;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityRoseDog.class, RenderRoseDog::new);
        RoseClientEvents.registerKey();
        MinecraftForge.EVENT_BUS.register(new RoseClientEvents());
    }
}
