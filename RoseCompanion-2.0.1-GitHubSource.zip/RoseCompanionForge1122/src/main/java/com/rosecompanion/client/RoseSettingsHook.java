package com.rosecompanion.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

/** Opens Rose's local-only credential screen from the pause menu or with O. */
@Mod.EventBusSubscriber(modid = "rosecompanion", value = Side.CLIENT)
public final class RoseSettingsHook {
    private static final int SETTINGS_BUTTON_ID = 29371;

    private RoseSettingsHook() {
    }

    @SubscribeEvent
    public static void onPauseMenuInit(GuiScreenEvent.InitGuiEvent.Post event) {
        if (!(event.getGui() instanceof GuiIngameMenu)) {
            return;
        }
        for (GuiButton button : event.getButtonList()) {
            if (button.id == SETTINGS_BUTTON_ID) {
                return;
            }
        }
        int x = event.getGui().width / 2 - 100;
        int y = event.getGui().height - 28;
        event.getButtonList().add(new GuiButton(
                SETTINGS_BUTTON_ID, x, y, 200, 20, "Rose AI Settings"));
    }

    @SubscribeEvent
    public static void onPauseMenuClick(GuiScreenEvent.ActionPerformedEvent.Pre event) {
        if (event.getGui() instanceof GuiIngameMenu
                && event.getButton().id == SETTINGS_BUTTON_ID) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiRoseSettings(event.getGui()));
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        if (!Keyboard.getEventKeyState() || Keyboard.getEventKey() != Keyboard.KEY_O) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft.player == null || minecraft.world == null || minecraft.currentScreen != null) {
            return;
        }
        minecraft.displayGuiScreen(new GuiRoseSettings(null));
    }
}
