package com.rosecompanion.item;

import com.rosecompanion.RoseCompanion;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = RoseCompanion.MODID)
public final class ModItems {
    public static final Item ROSE_WHISTLE = new ItemRoseWhistle();

    private ModItems() { }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(ROSE_WHISTLE);
    }
}
