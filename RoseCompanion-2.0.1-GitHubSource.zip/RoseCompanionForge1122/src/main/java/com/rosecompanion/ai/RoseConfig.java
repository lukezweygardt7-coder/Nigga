package com.rosecompanion.ai;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/** Local-only settings for Rose's two external AI services. */
public final class RoseConfig {
    public static String ASSEMBLYAI_API_KEY = "";
    public static String GEMINI_API_KEY = "";
    public static String GEMINI_MODEL = "gemini-3.8-flash";
    public static String ASSEMBLYAI_SPEECH_MODEL = "universal-3-5-pro";
    public static int VOICE_MAX_SECONDS = 90;

    private static File configFile;

    private RoseConfig() {
    }

    public static synchronized void load(File configDirectory) {
        if (configDirectory == null) {
            return;
        }
        if (!configDirectory.exists() && !configDirectory.mkdirs() && !configDirectory.isDirectory()) {
            return;
        }

        configFile = new File(configDirectory, "rosecompanion.properties");
        Properties properties = new Properties();
        if (configFile.isFile()) {
            try (FileInputStream input = new FileInputStream(configFile)) {
                properties.load(input);
            } catch (IOException ignored) {
                // Keep safe empty defaults; the user can correct the file and restart.
            }
        }

        ASSEMBLYAI_API_KEY = properties.getProperty("assemblyai_api_key", "").trim();
        GEMINI_API_KEY = properties.getProperty("gemini_api_key", "").trim();
        GEMINI_MODEL = properties.getProperty("gemini_model", "gemini-3.8-flash").trim();
        ASSEMBLYAI_SPEECH_MODEL = properties.getProperty(
                "assemblyai_speech_model", "universal-3-5-pro").trim();
        if (GEMINI_MODEL.isEmpty()) {
            GEMINI_MODEL = "gemini-3.8-flash";
        }
        if (!"universal-3-5-pro".equals(ASSEMBLYAI_SPEECH_MODEL)
                && !"universal-2".equals(ASSEMBLYAI_SPEECH_MODEL)) {
            ASSEMBLYAI_SPEECH_MODEL = "universal-3-5-pro";
        }

        try {
            VOICE_MAX_SECONDS = Math.max(10, Math.min(120,
                    Integer.parseInt(properties.getProperty("voice_max_seconds", "90").trim())));
        } catch (NumberFormatException ignored) {
            VOICE_MAX_SECONDS = 90;
        }

        boolean needsCurrentKeys = !properties.containsKey("assemblyai_api_key")
                || !properties.containsKey("gemini_api_key");
        if (!configFile.exists() || needsCurrentKeys) {
            // Replace an older one-key config with the current provider-specific template.
            // Old generic api_key fields are intentionally not re-used for either provider.
            saveDefaults();
        }
    }

    private static void saveDefaults() {
        if (configFile == null) {
            return;
        }
        Properties properties = new Properties();
        properties.setProperty("assemblyai_api_key", ASSEMBLYAI_API_KEY);
        properties.setProperty("gemini_api_key", GEMINI_API_KEY);
        properties.setProperty("gemini_model", GEMINI_MODEL);
        properties.setProperty("assemblyai_speech_model", ASSEMBLYAI_SPEECH_MODEL);
        properties.setProperty("voice_max_seconds", Integer.toString(VOICE_MAX_SECONDS));
        try (FileOutputStream output = new FileOutputStream(configFile)) {
            properties.store(output, "Rose Companion - keep both API keys private");
        } catch (IOException ignored) {
            // The config example shipped with the mod remains available as a manual fallback.
        }
    }
}
