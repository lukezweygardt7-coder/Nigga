package com.rosecompanion.client;

import com.rosecompanion.ai.RoseConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.text.TextComponentString;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/** Local-only in-game settings screen for Rose's AI credentials. */
public final class GuiRoseSettings extends GuiScreen {
    private final GuiScreen parent;
    private GuiTextField assemblyKeyField;
    private GuiTextField geminiKeyField;
    private String status = "Keys are stored only in this Minecraft profile.";

    public GuiRoseSettings(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void initGui() {
        this.buttonList.clear();
        int fieldWidth = Math.min(380, this.width - 32);
        int left = (this.width - fieldWidth) / 2;
        int saveY = Math.max(174, this.height - 42);

        this.assemblyKeyField = new GuiTextField(0, this.fontRenderer, left, 78, fieldWidth, 20);
        this.assemblyKeyField.setMaxStringLength(512);
        this.assemblyKeyField.setText(RoseConfig.ASSEMBLYAI_API_KEY == null ? "" : RoseConfig.ASSEMBLYAI_API_KEY);
        this.assemblyKeyField.setFocused(true);

        this.geminiKeyField = new GuiTextField(1, this.fontRenderer, left, 124, fieldWidth, 20);
        this.geminiKeyField.setMaxStringLength(512);
        this.geminiKeyField.setText(RoseConfig.GEMINI_API_KEY == null ? "" : RoseConfig.GEMINI_API_KEY);

        int buttonWidth = 90;
        int gap = 8;
        int startX = (this.width - (buttonWidth * 2 + gap)) / 2;
        this.buttonList.add(new GuiButton(0, startX, saveY, buttonWidth, 20, "Save"));
        this.buttonList.add(new GuiButton(1, startX + buttonWidth + gap, saveY, buttonWidth, 20, "Done"));
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 0) {
            saveSettings();
        } else if (button.id == 1) {
            this.mc.displayGuiScreen(this.parent);
        }
    }

    private void saveSettings() {
        Minecraft minecraft = Minecraft.getMinecraft();
        File configDirectory = new File(minecraft.mcDataDir, "config");
        if (!configDirectory.isDirectory() && !configDirectory.mkdirs()) {
            this.status = "Could not create the config folder. Check game-folder permissions.";
            return;
        }

        String assemblyKey = this.assemblyKeyField.getText().trim();
        String geminiKey = this.geminiKeyField.getText().trim();
        String geminiModel = emptyToDefault(RoseConfig.GEMINI_MODEL, "gemini-3.8-flash");
        String speechModel = emptyToDefault(RoseConfig.ASSEMBLYAI_SPEECH_MODEL, "universal-3-5-pro");

        Properties properties = new Properties();
        properties.setProperty("assemblyai_api_key", assemblyKey);
        properties.setProperty("gemini_api_key", geminiKey);
        properties.setProperty("gemini_model", geminiModel);
        properties.setProperty("assemblyai_speech_model", speechModel);
        properties.setProperty("voice_max_seconds", Integer.toString(RoseConfig.VOICE_MAX_SECONDS));

        File configFile = new File(configDirectory, "rosecompanion.properties");
        try (FileOutputStream output = new FileOutputStream(configFile)) {
            properties.store(output, "Rose Companion - credentials stay in this local Minecraft profile");
            RoseConfig.ASSEMBLYAI_API_KEY = assemblyKey;
            RoseConfig.GEMINI_API_KEY = geminiKey;
            RoseConfig.GEMINI_MODEL = geminiModel;
            RoseConfig.ASSEMBLYAI_SPEECH_MODEL = speechModel;
            this.status = "Saved locally. Press V to talk to Rose.";
            if (minecraft.player != null) {
                minecraft.player.sendMessage(new TextComponentString("§dRose: §fAI settings saved on this device."));
            }
        } catch (IOException exception) {
            this.status = "Could not save settings: " + exception.getMessage();
        }
    }

    private static String emptyToDefault(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            this.mc.displayGuiScreen(this.parent);
            return;
        }
        boolean handled = this.assemblyKeyField.textboxKeyTyped(typedChar, keyCode);
        handled |= this.geminiKeyField.textboxKeyTyped(typedChar, keyCode);
        if (!handled) {
            super.keyTyped(typedChar, keyCode);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        this.assemblyKeyField.mouseClicked(mouseX, mouseY, mouseButton);
        this.geminiKeyField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, "Rose AI Settings", this.width / 2, 25, 0xFFFFFF);
        int fieldWidth = Math.min(380, this.width - 32);
        int left = (this.width - fieldWidth) / 2;
        this.drawString(this.fontRenderer, "AssemblyAI API key", left, 63, 0xFFFFFF);
        this.assemblyKeyField.drawTextBox();
        this.drawString(this.fontRenderer, "Gemini API key", left, 109, 0xFFFFFF);
        this.geminiKeyField.drawTextBox();
        this.drawCenteredString(this.fontRenderer, "Paste or type keys here, then press Save.", this.width / 2, 153, 0xCCCCCC);
        this.drawCenteredString(this.fontRenderer, "Keys are saved locally and are not sent to the world/server.", this.width / 2, 165, 0xAAAAAA);
        this.drawCenteredString(this.fontRenderer, this.status, this.width / 2, 184, 0xFFCC66);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
