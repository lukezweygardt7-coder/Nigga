package com.rosecompanion.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rosecompanion.client.RoseClientEvents;
import net.minecraft.client.Minecraft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Voice pipeline: local WAV -> AssemblyAI transcription -> Gemini command intent.
 * Network work is called from RoseClientEvents' background worker, never the game thread.
 */
public final class RoseAIService {
    private static final String ASSEMBLYAI_BASE = "https://api.assemblyai.com/v2";
    private static final String GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final long TRANSCRIPTION_TIMEOUT_MS = 120000L;

    private RoseAIService() {
    }

    public static void processRecording(File wav, String worldSnapshot) {
        String assemblyKey = RoseConfig.ASSEMBLYAI_API_KEY;
        String geminiKey = RoseConfig.GEMINI_API_KEY;
        try {
            if (assemblyKey == null || assemblyKey.trim().isEmpty()
                    || geminiKey == null || geminiKey.trim().isEmpty()) {
                RoseClientEvents.chat("Add both API keys to config/rosecompanion.properties, then restart Minecraft.");
                return;
            }
            if (wav == null || !wav.isFile() || wav.length() < 1200L) {
                RoseClientEvents.chat("I couldn't read the recording. Please try speaking again.");
                return;
            }

            String transcript = transcribeWithAssemblyAI(wav, assemblyKey);
            if (transcript == null || transcript.trim().isEmpty()) {
                RoseClientEvents.chat("I didn't catch that. Try speaking a little more clearly.");
                return;
            }

            RoseClientEvents.chat("You said: \"" + clip(transcript, 150) + "\"");
            RoseIntent intent = interpretWithGemini(transcript, worldSnapshot, geminiKey);
            Minecraft.getMinecraft().addScheduledTask(() ->
                    RoseClientEvents.sendIntent(intent.action, intent.item, intent.response));
        } catch (Exception ex) {
            RoseClientEvents.chat("I couldn't connect to Rose's AI services: " + safeError(ex));
        } finally {
            if (wav != null && wav.exists()) {
                // Temporary audio is deleted after processing.
                //noinspection ResultOfMethodCallIgnored
                wav.delete();
            }
        }
    }

    private static String transcribeWithAssemblyAI(File wav, String apiKey) throws Exception {
        String uploadUrl = uploadAudio(wav, apiKey);

        JsonObject submit = new JsonObject();
        submit.addProperty("audio_url", uploadUrl);
        JsonArray speechModels = new JsonArray();
        speechModels.add(RoseConfig.ASSEMBLYAI_SPEECH_MODEL);
        submit.add("speech_models", speechModels);
        submit.addProperty("language_code", "en_us");

        JsonObject queued = postJson(ASSEMBLYAI_BASE + "/transcript", apiKey, submit);
        String transcriptId = getString(queued, "id", "");
        if (transcriptId.isEmpty()) {
            throw new IllegalStateException(errorMessage(queued, "AssemblyAI did not return a transcription ID."));
        }

        long deadline = System.currentTimeMillis() + TRANSCRIPTION_TIMEOUT_MS;
        while (System.currentTimeMillis() < deadline) {
            JsonObject status = getJson(ASSEMBLYAI_BASE + "/transcript/" + transcriptId, apiKey);
            String state = getString(status, "status", "");
            if ("completed".equalsIgnoreCase(state)) {
                return getString(status, "text", "");
            }
            if ("error".equalsIgnoreCase(state)) {
                throw new IllegalStateException(getString(status, "error", "AssemblyAI transcription failed."));
            }
            Thread.sleep(900L);
        }
        throw new IllegalStateException("AssemblyAI took too long to finish the recording. Please try again.");
    }

    private static String uploadAudio(File wav, String apiKey) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(ASSEMBLYAI_BASE + "/upload").openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Authorization", apiKey);
        connection.setRequestProperty("Content-Type", "application/octet-stream");
        connection.setFixedLengthStreamingMode((int) Math.min(Integer.MAX_VALUE, wav.length()));

        try (OutputStream output = connection.getOutputStream();
             InputStream input = new FileInputStream(wav)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
        }

        JsonObject response = readJsonResponse(connection);
        String url = getString(response, "upload_url", "");
        if (url.isEmpty()) {
            throw new IllegalStateException(errorMessage(response, "AssemblyAI did not return an upload URL."));
        }
        return url;
    }

    private static RoseIntent interpretWithGemini(String transcript, String worldSnapshot, String apiKey)
            throws Exception {
        String model = RoseConfig.GEMINI_MODEL == null || RoseConfig.GEMINI_MODEL.trim().isEmpty()
                ? "gemini-3.8-flash" : RoseConfig.GEMINI_MODEL.trim();
        String endpoint = GEMINI_BASE + URLEncoder.encode(model, "UTF-8") + ":generateContent";

        JsonObject systemPart = new JsonObject();
        systemPart.addProperty("text",
                "You are Rose, a clever, affectionate Minecraft dog companion made for Sophie. "
                + "Interpret the player's spoken request and respond as a friendly dog. "
                + "Return ONLY one JSON object with exactly these string keys: action, item, response. "
                + "action must be one of: answer, reject, follow, sit, dig_item, build_house. "
                + "Use answer for ordinary conversation and yes/no questions. If the player says I love you, "
                + "respond yes warmly. Use reject and a polite no for unreasonable requests such as an 80-floor mansion. "
                + "Use build_house only for a modest simple starter house. Use dig_item for requests to find, fetch, "
                + "or dig up a named item. For dig_item, item must be one of: minecraft:diamond, minecraft:bone, "
                + "minecraft:stick, minecraft:iron_ingot, minecraft:gold_ingot, minecraft:emerald, minecraft:coal, "
                + "minecraft:apple, minecraft:bread, minecraft:torch, minecraft:string, minecraft:feather, "
                + "minecraft:spider_eye, minecraft:rotten_flesh, minecraft:oak_planks. Never invent item IDs. "
                + "For follow or sit, item must be an empty string. Keep response friendly and under 18 words. "
                + "Do not output commands or code. The world snapshot only describes a small nearby area; "
                + "do not claim to know unseen terrain.");
        JsonArray systemParts = new JsonArray();
        systemParts.add(systemPart);
        JsonObject systemInstruction = new JsonObject();
        systemInstruction.add("parts", systemParts);

        String userText = "The player said: " + transcript
                + "\nLocal Minecraft sensor snapshot: "
                + (worldSnapshot == null ? "unavailable" : worldSnapshot);
        JsonObject userPart = new JsonObject();
        userPart.addProperty("text", userText);
        JsonArray userParts = new JsonArray();
        userParts.add(userPart);
        JsonObject userContent = new JsonObject();
        userContent.addProperty("role", "user");
        userContent.add("parts", userParts);
        JsonArray contents = new JsonArray();
        contents.add(userContent);

        JsonObject generationConfig = new JsonObject();
        generationConfig.addProperty("responseMimeType", "application/json");
        generationConfig.addProperty("temperature", 0.2D);
        generationConfig.addProperty("maxOutputTokens", 220);

        JsonObject request = new JsonObject();
        request.add("systemInstruction", systemInstruction);
        request.add("contents", contents);
        request.add("generationConfig", generationConfig);

        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setDoOutput(true);
        connection.setRequestProperty("x-goog-api-key", apiKey);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        byte[] body = request.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream output = connection.getOutputStream()) {
            output.write(body);
        }

        JsonObject response = readJsonResponse(connection);
        String generatedText = extractGeminiText(response);
        if (generatedText == null || generatedText.trim().isEmpty()) {
            throw new IllegalStateException(errorMessage(response, "Gemini returned an empty response."));
        }
        return parseIntent(generatedText);
    }

    private static String extractGeminiText(JsonObject root) {
        if (!root.has("candidates") || !root.get("candidates").isJsonArray()) {
            return null;
        }
        JsonArray candidates = root.getAsJsonArray("candidates");
        if (candidates.size() == 0 || !candidates.get(0).isJsonObject()) {
            return null;
        }
        JsonObject candidate = candidates.get(0).getAsJsonObject();
        if (!candidate.has("content") || !candidate.get("content").isJsonObject()) {
            return null;
        }
        JsonObject content = candidate.getAsJsonObject("content");
        if (!content.has("parts") || !content.get("parts").isJsonArray()) {
            return null;
        }
        StringBuilder text = new StringBuilder();
        for (JsonElement partElement : content.getAsJsonArray("parts")) {
            if (partElement.isJsonObject() && partElement.getAsJsonObject().has("text")) {
                if (text.length() > 0) text.append('\n');
                text.append(partElement.getAsJsonObject().get("text").getAsString());
            }
        }
        return text.length() == 0 ? null : text.toString();
    }

    private static RoseIntent parseIntent(String modelText) {
        String trimmed = modelText == null ? "" : modelText.trim();
        int first = trimmed.indexOf('{');
        int last = trimmed.lastIndexOf('}');
        if (first >= 0 && last > first) {
            try {
                JsonObject json = new JsonParser().parse(trimmed.substring(first, last + 1)).getAsJsonObject();
                String action = getString(json, "action", "answer").toLowerCase();
                String item = getString(json, "item", "").toLowerCase();
                String response = getString(json, "response", "Woof!");
                if (!action.equals("answer") && !action.equals("reject") && !action.equals("follow")
                        && !action.equals("sit") && !action.equals("dig_item") && !action.equals("build_house")) {
                    action = "answer";
                }
                return new RoseIntent(action, item, clip(response, 220));
            } catch (Exception ignored) {
                // Fall through to a harmless conversational reply.
            }
        }
        return new RoseIntent("answer", "", clip(trimmed, 160));
    }

    private static JsonObject postJson(String url, String apiKey, JsonObject payload) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Authorization", apiKey);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream output = connection.getOutputStream()) {
            output.write(body);
        }
        return readJsonResponse(connection);
    }

    private static JsonObject getJson(String url, String apiKey) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setRequestProperty("Authorization", apiKey);
        return readJsonResponse(connection);
    }

    private static JsonObject readJsonResponse(HttpURLConnection connection) throws Exception {
        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) {
            connection.disconnect();
            throw new IllegalStateException("The AI service returned HTTP " + code + ".");
        }
        StringBuilder body = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
        } finally {
            connection.disconnect();
        }
        if (code < 200 || code >= 300) {
            throw new IllegalStateException("HTTP " + code + ": " + clip(body.toString(), 220));
        }
        return parseObject(body.toString());
    }

    private static JsonObject parseObject(String raw) {
        JsonElement parsed = new JsonParser().parse(raw);
        if (!parsed.isJsonObject()) {
            throw new IllegalStateException("The AI service returned an unexpected response.");
        }
        return parsed.getAsJsonObject();
    }

    private static String errorMessage(JsonObject json, String fallback) {
        if (json.has("error") && json.get("error").isJsonObject()) {
            JsonObject error = json.getAsJsonObject("error");
            if (error.has("message")) return error.get("message").getAsString();
        }
        if (json.has("error") && json.get("error").isJsonPrimitive()) {
            return json.get("error").getAsString();
        }
        return fallback;
    }

    private static String getString(JsonObject object, String key, String fallback) {
        return object.has(key) && !object.get(key).isJsonNull()
                ? object.get(key).getAsString() : fallback;
    }

    private static String safeError(Exception ex) {
        String message = ex.getMessage();
        if (message == null || message.trim().isEmpty()) return ex.getClass().getSimpleName();
        return clip(message, 180);
    }

    private static String clip(String value, int limit) {
        if (value == null) return "";
        String clean = value.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() <= limit ? clean : clean.substring(0, limit - 3) + "...";
    }

    public static final class RoseIntent {
        public final String action;
        public final String item;
        public final String response;

        public RoseIntent(String action, String item, String response) {
            this.action = action == null ? "answer" : action;
            this.item = item == null ? "" : item;
            this.response = response == null ? "Woof!" : response;
        }
    }
}
